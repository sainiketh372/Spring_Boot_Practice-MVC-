package com.example.lms.bean;

import java.util.Random;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

@Entity
@Table(name = "books")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Book {

	@Id
	private String bookId;

	@NotBlank(message = "Book title must not be blank")
	@Size(min = 3, max = 50, message = "Book title must be between 3 and 50 characters")
	@Column(nullable = false)
	private String title;

	@NotBlank(message = "Author name must not be blank")
	@Pattern(regexp = "^[A-Za-z ]+$", message = "Author name must contain only alphabets and spaces")
	@Column(nullable = false)
	private String author;

	@Pattern(regexp = "^[0-9]{13}$", message = "ISBN must be exactly 13 digits")
	@Column(unique = true, nullable = false)
	private String isbn;

	@NotBlank(message = "Book category must not be blank")
	@Size(min = 3, max = 30, message = "Book category must be between 3 and 30 characters")
	@Column(nullable = false)
	private String category;

	@Min(value = 1, message = "Total copies must be at least 1")
	@Column(nullable = false)
	private Integer totalCopies;

	@Min(value = 0, message = "Available copies cannot be negative")
	@Column(nullable = false)
	private Integer availableCopies;

	// ✅ Print student, but student will NOT print books/marks
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "student_id", nullable = false)
	@JsonIgnoreProperties({ "books", "marksTable" })
	private Student student;

	@PrePersist
	public void generateBookIdAndIsbn() {

		if (this.bookId == null || this.bookId.isBlank()) {
			this.bookId = "BOOK-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
		}

		if (this.isbn == null || this.isbn.isBlank()) {
			long isbnNumber = 1_000_000_000_000L + new Random().nextLong(9_000_000_000_000L);
			this.isbn = String.valueOf(isbnNumber);
		}
	}
}
