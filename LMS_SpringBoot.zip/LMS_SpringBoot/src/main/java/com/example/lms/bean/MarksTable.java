package com.example.lms.bean;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.util.Random;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "marks_table")
public class MarksTable {

	@Id
	private String marksId;

	@Column
	@NotBlank(message = "Exam title must not be blank")
	@Size(min = 3, max = 50, message = "Exam title must be between 3 and 50 characters")
	private String examTitle;

	@Column
	@Min(value = 0, message = "Maths marks cannot be less than 0")
	@Max(value = 100, message = "Maths marks cannot exceed 100")
	private Integer maths;

	@Column
	@Min(value = 0, message = "Science marks cannot be less than 0")
	@Max(value = 100, message = "Science marks cannot exceed 100")
	private Integer science;

	@Column
	@Min(value = 0, message = "Computers marks cannot be less than 0")
	@Max(value = 100, message = "Computers marks cannot exceed 100")
	private Integer computers;

	@Column
	@Min(value = 0, message = "English marks cannot be less than 0")
	@Max(value = 100, message = "English marks cannot exceed 100")
	private Integer english;

	@Column
	@Min(value = 0, message = "Total marks cannot be negative")
	private Integer total;

	@Column
	@Pattern(regexp = "PASS|FAIL", message = "Result must be either PASS or FAIL")
	private String result;

	// ✅ Print student, but student will NOT print books/marks
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "student_id", nullable = false, unique = true)
	@JsonIgnoreProperties({ "books", "marksTable" })
	private Student student;

	@PrePersist
	public void generateMarksAndResult() {

		if (this.marksId == null || this.marksId.isBlank()) {
			this.marksId = "MARKS-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
		}
		Random random = new Random();
		if (this.maths == null)
			this.maths = random.nextInt(101);
		if (this.science == null)
			this.science = random.nextInt(101);
		if (this.computers == null)
			this.computers = random.nextInt(101);
		if (this.english == null)
			this.english = random.nextInt(101);
		this.total = maths + science + computers + english;
		this.result = (total >= 160) ? "PASS" : "FAIL";
	}
}
