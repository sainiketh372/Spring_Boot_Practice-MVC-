package com.example.lms.bean;

import java.util.UUID;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "students")
public class Student {

	@Id
	@NotBlank(message = "Student ID must not be blank")
	private String studentId;

	@Column
	@NotBlank(message = "Student name must not be blank")
	@Pattern(regexp = "^[A-Za-z ]{3,40}$", message = "Name must contain only alphabets")
	private String name;

	@Column
	@NotBlank(message = "Email must not be blank")
	@Email(message = "Email format is invalid")
	@Pattern(regexp = "^[A-Za-z0-9._%+-]+@(gmail|yahoo|outlook|hotmail)\\.com$", message = "Email must end with @gmail.com, @yahoo.com, @outlook.com, or @hotmail.com")
	private String email;

	@Column
	@NotBlank(message = "Mobile number must not be blank")
	@Pattern(regexp = "^[6-9][0-9]{9}$", message = "Invalid Indian mobile number")
	private String mobile;

	@Column
	@Min(value = 1, message = "Semester must be at least 1")
	@Max(value = 8, message = "Semester must not exceed 8")
	private int semester;

	@OneToOne(mappedBy = "student", cascade = CascadeType.ALL)
	private MarksTable marksTable;

	@OneToMany(mappedBy = "student", cascade = CascadeType.ALL)
	private java.util.List<Book> books;

	@PrePersist
	public void generateStudentId() {
		if (this.studentId == null || this.studentId.isBlank()) {
			this.studentId = "STU-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
		}
	}
}
