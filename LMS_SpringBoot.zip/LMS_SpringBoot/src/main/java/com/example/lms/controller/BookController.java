package com.example.lms.controller;

import com.example.lms.bean.Book;
import com.example.lms.service.BookService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {

	private final BookService bookService;

	public BookController(BookService bookService) {
		this.bookService = bookService;
	}

	// ✅ SAVE ONE BOOK (Student → Book)
	@PostMapping("/savebook/{studentId}")
	public ResponseEntity<Book> addBook(@PathVariable String studentId, @RequestBody Book book) {

		Book savedBook = bookService.addBook(studentId, book);
		return new ResponseEntity<>(savedBook, HttpStatus.OK);
	}

	// ✅ SAVE BULK BOOKS FOR ONE STUDENT
	@PostMapping("/saveallbooks/{studentId}")
	public ResponseEntity<List<Book>> addBooks(@PathVariable String studentId, @RequestBody List<Book> books) {

		List<Book> savedBooks = bookService.addBooks(studentId, books);
		return new ResponseEntity<>(savedBooks, HttpStatus.OK);
	}

	@GetMapping("/getallbooks")
	public ResponseEntity<List<Book>> getAllBooks() {
		return new ResponseEntity<>(bookService.getAllBooks(), HttpStatus.OK);
	}

	@GetMapping("/getbookbyid/{id}")
	public ResponseEntity<Book> getBookById(@PathVariable String id) {
		Book book = bookService.getBookById(id);
		return new ResponseEntity<>(book, HttpStatus.OK);
	}

	@DeleteMapping("/deletebook/{id}")
	public ResponseEntity<String> deleteBook(@PathVariable String id) {
		bookService.deleteBook(id);
		return new ResponseEntity<>("Book deleted successfully", HttpStatus.OK);
	}
}
