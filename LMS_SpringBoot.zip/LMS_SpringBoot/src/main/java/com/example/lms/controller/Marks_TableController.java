package com.example.lms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.lms.bean.MarksTable;
import com.example.lms.service.Marks_TableService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/marks")
public class Marks_TableController {

	@Autowired
	private Marks_TableService service;

	// ✅ SAVE ONE MARKS (ONE-BY-ONE)
	@PostMapping("/saveMarks/{studentId}")
	public ResponseEntity<MarksTable> addMarks(@PathVariable String studentId, @Valid @RequestBody MarksTable obj) {

		MarksTable savedMarks = service.saveMarks(studentId, obj);
		return new ResponseEntity<>(savedMarks, HttpStatus.OK);
	}

	// ⚠️ OPTIONAL: BULK SAVE (student must already be set in each object)
//    @PostMapping("/saveallMarks")
//    public ResponseEntity<List<MarksTable>> addAllMarks(
//            @Valid @RequestBody List<MarksTable> obj) {
//
//        List<MarksTable> savedMarks = service.addAllMarks(obj);
//        return new ResponseEntity<>(savedMarks, HttpStatus.OK);
//    }

	@GetMapping("/getallMarks")
	public ResponseEntity<List<MarksTable>> getAllMarks() {
		return new ResponseEntity<>(service.getAllMarks(), HttpStatus.OK);
	}

	@GetMapping("/getmarksbyid/{id}")
	public ResponseEntity<MarksTable> getMarksById(@PathVariable String id) {
		MarksTable marks = service.getMarksById(id);
		return new ResponseEntity<>(marks, HttpStatus.OK);
	}

	@DeleteMapping("/deletemarks/{id}")
	public ResponseEntity<String> deleteMarks(@PathVariable String id) {
		service.deleteMarks(id);
		return new ResponseEntity<>("Marks deleted successfully", HttpStatus.OK);
	}
}
