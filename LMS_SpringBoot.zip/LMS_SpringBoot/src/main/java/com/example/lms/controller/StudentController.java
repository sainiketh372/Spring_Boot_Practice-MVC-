package com.example.lms.controller;

import com.example.lms.bean.Student;
import com.example.lms.service.StudentService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/students")
public class StudentController {

	@Autowired
	private StudentService studentService;

	@PostMapping("/savestudent")
	public ResponseEntity<Student> addStudent(@Valid @RequestBody Student student) {
		Student savedStudent = studentService.addStudent(student);
		return new ResponseEntity<>(savedStudent, HttpStatus.OK);
	}

	@PostMapping("/savestudents")
	public ResponseEntity<List<Student>> addStudents(@Valid @RequestBody List<Student> students) {
		List<Student> savedStudents = studentService.addStudents(students);
		return new ResponseEntity<>(savedStudents, HttpStatus.OK);
	}

	@Transactional(readOnly = true)
	@GetMapping("/getallstudents")
	public ResponseEntity<List<Student>> getAllStudents() {
		return new ResponseEntity<>(studentService.getAllStudents(), HttpStatus.OK);
	}

	@GetMapping("/getstuentbyid/{id}")
	public ResponseEntity<Student> getStudentById(@PathVariable String id) {
		Student student = studentService.getStudentById(id);
		return new ResponseEntity<>(student, HttpStatus.OK);
	}

	@DeleteMapping("/deletestudent/{id}")
	public ResponseEntity<String> deleteStudent(@PathVariable String id) {
		studentService.deleteStudent(id);
		return new ResponseEntity<>("Student deleted successfully", HttpStatus.OK);
	}
}
