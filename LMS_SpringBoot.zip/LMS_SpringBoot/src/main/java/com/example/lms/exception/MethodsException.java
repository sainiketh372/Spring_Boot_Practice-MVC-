package com.example.lms.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class MethodsException {

	@ExceptionHandler(exception = MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String, String>> handleBeanObject(MethodArgumentNotValidException me) {
		BindingResult br = me.getBindingResult();
		Map<String, String> res = new HashMap<>();
		br.getFieldErrors().forEach(x -> res.put(x.getField(), x.getDefaultMessage()));
		return new ResponseEntity<>(res, HttpStatus.BAD_REQUEST);
	}

}
