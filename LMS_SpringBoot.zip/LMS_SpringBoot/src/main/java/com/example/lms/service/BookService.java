package com.example.lms.service;

import com.example.lms.bean.Book;
import com.example.lms.bean.Student;
import com.example.lms.repo.BookRepository;
import com.example.lms.repo.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

	private final BookRepository bookRepository;
	private final StudentRepository studentRepository;

	public BookService(BookRepository bookRepository, StudentRepository studentRepository) {
		this.bookRepository = bookRepository;
		this.studentRepository = studentRepository;
	}

	// ✅ SAVE ONE BOOK (ORM SAFE)
	public Book addBook(String studentId, Book book) {

		Student student = studentRepository.findById(studentId)
				.orElseThrow(() -> new RuntimeException("Student not found with id: " + studentId));

		book.setStudent(student); // owning side
		student.getBooks().add(book); // inverse side

		return bookRepository.save(book);
	}

	// ✅ SAVE BULK BOOKS FOR ONE STUDENT
	public List<Book> addBooks(String studentId, List<Book> books) {

		Student student = studentRepository.findById(studentId)
				.orElseThrow(() -> new RuntimeException("Student not found with id: " + studentId));

		for (Book book : books) {
			book.setStudent(student);
		}

		return bookRepository.saveAll(books);
	}

	public List<Book> getAllBooks() {
		return bookRepository.findAll();
	}

	public Book getBookById(String id) {
		return bookRepository.findById(id).orElseThrow(() -> new RuntimeException("Book not found with id: " + id));
	}

	public void deleteBook(String id) {
		bookRepository.deleteById(id);
	}
}
