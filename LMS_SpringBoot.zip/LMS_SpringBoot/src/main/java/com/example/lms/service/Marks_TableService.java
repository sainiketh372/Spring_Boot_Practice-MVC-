package com.example.lms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.lms.bean.MarksTable;
import com.example.lms.bean.Student;
import com.example.lms.repo.Marks_TableRepository;
import com.example.lms.repo.StudentRepository;

@Service
public class Marks_TableService {

	@Autowired
	private Marks_TableRepository repo;

	@Autowired
	private StudentRepository studentRepo;

	public MarksTable saveMarks(String studentId, MarksTable marks) {

		Student student = studentRepo.findById(studentId)
				.orElseThrow(() -> new RuntimeException("Student not found with id: " + studentId));

		marks.setStudent(student);
		student.setMarksTable(marks);

		return repo.save(marks);
	}

//    public List<MarksTable> addAllMarks(List<MarksTable> marksList) {
//        return repo.saveAll(marksList);
//    }

	public List<MarksTable> getAllMarks() {
		return repo.findAll();
	}

	public MarksTable getMarksById(String id) {
		return repo.findById(id).orElseThrow(() -> new RuntimeException("Marks not found with id: " + id));
	}

	public void deleteMarks(String id) {
		repo.deleteById(id);
	}
}
